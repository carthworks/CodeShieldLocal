// SEC110 - disabling TLS verification (demo)
process.env.NODE_TLS_REJECT_UNAUTHORIZED = '0'; // insecure - disables cert checks
console.log('tls verification disabled (demo)');
