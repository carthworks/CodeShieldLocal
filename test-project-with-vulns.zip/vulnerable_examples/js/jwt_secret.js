// SEC118 - hardcoded JWT secret
const JWT_SECRET = 'hardcoded_jwt_secret_please_change'; // should be env var
module.exports = JWT_SECRET;
