// SEC106 - SQL-like string concatenation
function findUser(username) {
  const q = "SELECT * FROM users WHERE username = '" + username + "'"; // unsafe concatenation
  console.log(q);
}
