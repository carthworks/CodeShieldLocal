// SEC100 - Hardcoded password
const password = "SuperSecret123!"; // hardcoded password should be detected by scanner
console.log("demo user created");
