// SEC117 - passing string to setTimeout (eval-like)
setTimeout("console.log('string run')", 1000); // avoid using string args
