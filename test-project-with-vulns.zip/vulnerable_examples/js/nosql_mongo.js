// SEC107 - MongoDB $where usage example (unsafe)
const query = { $where: "this.score > 10" }; // string-based predicate - risky
console.log(query);
