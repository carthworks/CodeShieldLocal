// SEC112 - environment variable logged directly
console.log('Secret is', process.env.MY_SECRET); // prints env var
