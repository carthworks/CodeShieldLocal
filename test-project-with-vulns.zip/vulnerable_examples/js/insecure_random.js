// SEC108 - insecure random used for token generation
function makeToken() {
  return Math.random().toString(36).slice(2); // not secure for secrets
}
