// SEC113 - path traversal via naive concat (demo)
const fs = require('fs');
function readUserFile(userInput) {
  // DO NOT use in production - vulnerable to ../../ paths
  const path = '/var/data/' + userInput;
  // fs.readFileSync(path, 'utf8'); // commented to avoid file system access
  console.log('would read', path);
}
