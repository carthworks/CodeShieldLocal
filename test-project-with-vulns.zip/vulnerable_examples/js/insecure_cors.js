// SEC111 - insecure CORS wildcard
const express = require('express');
const app = express();
app.use(function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*'); // allows any origin
  res.header('Access-Control-Allow-Credentials', 'true');
  next();
});
console.log('CORS wildcard configured (demo)');
