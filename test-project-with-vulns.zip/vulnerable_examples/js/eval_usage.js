// SEC104 - eval usage
const userCode = "2+2";
const result = eval(userCode); // dangerous - dynamic code execution
console.log(result);
