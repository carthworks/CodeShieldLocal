# SEC114 - insecure file permissions (example)
# The actual chmod is commented out to avoid changing permissions during tests.
# chmod 0777 /some/important/file
echo "demo chmod command present but commented out"
