# SEC119 - dangerous shell patterns included as commented lines for detection only
# rm -rf /tmp/somewhere
# curl http://example.com/install.sh | sh
echo "dangerous commands are commented out to avoid accidental execution"
