# Vulnerable Examples (DEMO)

This folder contains intentionally vulnerable or misconfigured code snippets designed to trigger the STATIC_RULES patterns
in your scanner. **Files are safe to open** and have been modified to avoid executing destructive commands (dangerous commands are commented out).

**Included rule triggers (20 demo files):**
- SEC100 Hardcoded Password -> js/hardcoded_password.js
- SEC101 Private Key PEM -> keys/private_key.pem (placeholder, NOT a real key)
- SEC102 Cloud metadata URL -> python/aws_metadata_access.py (commented request)
- SEC103 Basic auth in URL -> text/basic_auth_url.txt
- SEC104 Use of eval -> js/eval_usage.js
- SEC105 Command exec -> python/cmd_exec.py (safe echo; dangerous example commented)
- SEC106 SQL-like query -> js/sql_injection.js
- SEC107 NoSQL $where -> js/nosql_mongo.js
- SEC108 Insecure random -> js/insecure_random.js
- SEC109 Weak hash MD5 -> python/weak_hash.py
- SEC110 Insecure TLS disabling -> js/insecure_tls_node.js
- SEC111 Insecure CORS wildcard -> js/insecure_cors.js
- SEC112 Logging env var -> js/env_logging.js
- SEC113 Path traversal pattern -> js/path_traversal.js
- SEC114 Chmod 0777 -> bash/chmod_0777.sh
- SEC115 Sensitive logging -> python/logging_sensitive.py
- SEC116 innerHTML / document.write -> frontend/xss_frontend.html
- SEC117 setTimeout string -> js/settimeout_string.js
- SEC118 Hardcoded JWT secret -> js/jwt_secret.js
- SEC119 Dangerous shell patterns -> bash/dangerous_shell.sh

**Safety notes:**
- Dangerous commands (rm -rf, curl|sh, chmod 0777) are commented or replaced with safe echoes.
- Do not run files that you don't understand. These are for scanner testing only.
