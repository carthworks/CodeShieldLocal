# SEC105 - command execution (safe demo)
import os
# Demonstration: a safe command executed. Avoid running dangerous commands.
os.system("echo 'this is safe'")
# The following dangerous command is included as a commented string for detection only:
# os.system("rm -rf /")  # DO NOT UNCOMMENT — dangerous
