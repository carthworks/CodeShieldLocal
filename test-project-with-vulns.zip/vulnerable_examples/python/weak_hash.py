# SEC109 - weak hash usage
import hashlib
def fingerprint(data):
    return hashlib.md5(data.encode()).hexdigest()  # MD5 is weak
print(fingerprint('demo'))
