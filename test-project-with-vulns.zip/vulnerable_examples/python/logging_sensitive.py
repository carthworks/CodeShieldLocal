# SEC115 - excessive logging of sensitive data
token = 'tok_demo_12345'
print('user token:', token)  # should not log tokens in real apps
