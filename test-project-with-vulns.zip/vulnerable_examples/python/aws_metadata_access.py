# SEC102 - Cloud metadata access (commented to avoid accidental requests)
# import requests
# resp = requests.get('http://169.254.169.254/latest/meta-data/iam/security-credentials/')
# print(resp.text)
# Example request string present to trigger pattern matching.
url = "http://169.254.169.254/latest/meta-data/"
print("metadata url (demo)", url)
