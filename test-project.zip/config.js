module.exports = {
    apiKey: "sk-1234567890abcdefghijklmnop",
    dbPassword: "admin123",
    jwtSecret: "secret"
};
